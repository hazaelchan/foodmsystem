import { ShoppingCart } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"

interface DepartmentCardProps {
  name: string
  hasOrders: boolean
}

export default function DepartmentCard({ name, hasOrders }: DepartmentCardProps) {
  return (
    <Card className="h-48 transition-all hover:shadow-md cursor-pointer">
      <CardContent className="p-6 h-full flex flex-col justify-between">
        <div className="flex justify-between items-start">
          <h3 className="text-xl font-semibold">{name} Department</h3>
          <div className={`relative ${hasOrders ? "animate-pulse" : ""}`}>
            <ShoppingCart className={`h-6 w-6 ${hasOrders ? "text-red-500" : "text-gray-400"}`} />
            {hasOrders && <span className="absolute -top-1 -right-1 h-3 w-3 rounded-full bg-red-500"></span>}
          </div>
        </div>

        <div className="mt-4">
          {hasOrders ? (
            <div className="text-sm font-medium text-red-500">New orders available!</div>
          ) : (
            <div className="text-sm text-gray-500">No pending orders</div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}

