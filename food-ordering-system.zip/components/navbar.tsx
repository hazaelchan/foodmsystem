import { Bell } from "lucide-react"

export default function Navbar() {
  return (
    <header className="sticky top-0 z-50 w-full border-b bg-white">
      <div className="container flex h-16 items-center px-4 sm:px-6">
        <div className="flex items-center justify-between w-full">
          <h1 className="text-2xl font-bold tracking-tight">Food Ordering System</h1>
          <div className="flex items-center gap-4">
            <Bell className="h-6 w-6 text-gray-500" />
            <div className="h-8 w-8 rounded-full bg-primary flex items-center justify-center text-white font-medium">
              A
            </div>
          </div>
        </div>
      </div>
    </header>
  )
}

