"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Printer, Check } from "lucide-react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

interface StudentOrderListProps {
  departmentId: string
  year: string
}

export default function StudentOrderList({ departmentId, year }: StudentOrderListProps) {
  // Mock data for student orders
  const mockOrders = [
    { id: 1, name: "John Doe", studentId: "ST12345", meal: "Chicken Sandwich", time: "10:30 AM", fulfilled: false },
    { id: 2, name: "Jane Smith", studentId: "ST12346", meal: "Vegetable Salad", time: "11:15 AM", fulfilled: false },
    { id: 3, name: "Michael Johnson", studentId: "ST12347", meal: "Beef Burger", time: "11:45 AM", fulfilled: false },
    { id: 4, name: "Sarah Williams", studentId: "ST12348", meal: "Fish & Chips", time: "12:00 PM", fulfilled: false },
  ]

  const [orders, setOrders] = useState(mockOrders)

  const fulfillOrder = (orderId: number) => {
    setOrders(orders.map((order) => (order.id === orderId ? { ...order, fulfilled: true } : order)))
  }

  return (
    <div className="overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Student ID</TableHead>
            <TableHead>Name</TableHead>
            <TableHead>Meal</TableHead>
            <TableHead>Order Time</TableHead>
            <TableHead>Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {orders.map((order) => (
            <TableRow key={order.id} className={order.fulfilled ? "bg-gray-100" : ""}>
              <TableCell>{order.studentId}</TableCell>
              <TableCell>{order.name}</TableCell>
              <TableCell>{order.meal}</TableCell>
              <TableCell>{order.time}</TableCell>
              <TableCell>
                <div className="flex space-x-2">
                  <Button size="sm" variant="outline" onClick={() => alert("Printing receipt...")}>
                    <Printer className="h-4 w-4 mr-1" />
                    Print
                  </Button>

                  <Button
                    size="sm"
                    variant={order.fulfilled ? "secondary" : "default"}
                    onClick={() => fulfillOrder(order.id)}
                    disabled={order.fulfilled}
                  >
                    {order.fulfilled ? (
                      <>
                        <Check className="h-4 w-4 mr-1" />
                        Fulfilled
                      </>
                    ) : (
                      "Fulfill Order"
                    )}
                  </Button>
                </div>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}

