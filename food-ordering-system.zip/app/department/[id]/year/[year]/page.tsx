import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import Navbar from "@/components/navbar"
import { ArrowLeft, Printer } from "lucide-react"
import StudentOrderList from "@/components/student-order-list"

export default function YearOrdersPage({
  params,
}: {
  params: { id: string; year: string }
}) {
  // Convert department ID to proper name
  const departmentNames: Record<string, string> = {
    it: "IT",
    bio: "Biology",
    agric: "Agriculture",
    tourism: "Tourism",
    etech: "ETech",
    architecture: "Architecture",
    business: "Business",
  }

  const departmentName = departmentNames[params.id] || params.id
  const yearName = params.year === "1" ? "First" : "Second"

  return (
    <main className="min-h-screen bg-gray-50">
      <Navbar />

      <div className="container mx-auto p-6">
        <div className="flex items-center mb-6">
          <Link href={`/department/${params.id}`}>
            <Button variant="ghost" size="icon" className="mr-2">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <h2 className="text-2xl font-bold">
            {departmentName} Department - {yearName} Year Orders
          </h2>
        </div>

        <Card>
          <CardContent className="p-6">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-xl font-semibold">Student Orders</h3>
              <Button>
                <Printer className="h-4 w-4 mr-2" />
                Print All Receipts
              </Button>
            </div>

            <StudentOrderList departmentId={params.id} year={params.year} />
          </CardContent>
        </Card>
      </div>
    </main>
  )
}

