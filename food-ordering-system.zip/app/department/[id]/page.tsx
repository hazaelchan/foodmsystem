import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import Navbar from "@/components/navbar"
import { ArrowLeft } from "lucide-react"

export default function DepartmentPage({ params }: { params: { id: string } }) {
  // Convert department ID to proper name
  const departmentNames: Record<string, string> = {
    it: "IT",
    bio: "Biology",
    agric: "Agriculture",
    tourism: "Tourism",
    etech: "ETech",
    architecture: "Architecture",
    business: "Business",
  }

  const departmentName = departmentNames[params.id] || params.id

  return (
    <main className="min-h-screen bg-gray-50">
      <Navbar />

      <div className="container mx-auto p-6">
        <div className="flex items-center mb-6">
          <Link href="/">
            <Button variant="ghost" size="icon" className="mr-2">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <h2 className="text-2xl font-bold">{departmentName} Department Orders</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Link href={`/department/${params.id}/year/1`}>
            <Card className="h-40 transition-all hover:shadow-md cursor-pointer">
              <CardContent className="p-6 h-full flex flex-col justify-center items-center">
                <h3 className="text-2xl font-bold">First Year</h3>
                <p className="text-gray-500 mt-2">View orders from first year students</p>
              </CardContent>
            </Card>
          </Link>

          <Link href={`/department/${params.id}/year/2`}>
            <Card className="h-40 transition-all hover:shadow-md cursor-pointer">
              <CardContent className="p-6 h-full flex flex-col justify-center items-center">
                <h3 className="text-2xl font-bold">Second Year</h3>
                <p className="text-gray-500 mt-2">View orders from second year students</p>
              </CardContent>
            </Card>
          </Link>
        </div>
      </div>
    </main>
  )
}

