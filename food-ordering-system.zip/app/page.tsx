import Link from "next/link"
import Navbar from "@/components/navbar"
import DepartmentCard from "@/components/department-card"

export default function Dashboard() {
  // Mock data for departments with orders
  const departments = [
    { id: "it", name: "IT", hasOrders: true },
    { id: "bio", name: "Biology", hasOrders: false },
    { id: "agric", name: "Agriculture", hasOrders: true },
    { id: "tourism", name: "Tourism", hasOrders: false },
    { id: "etech", name: "ETech", hasOrders: false },
    { id: "architecture", name: "Architecture", hasOrders: true },
    { id: "business", name: "Business", hasOrders: false },
  ]

  return (
    <main className="min-h-screen bg-gray-50">
      <Navbar />

      <div className="container mx-auto p-6">
        <h2 className="text-2xl font-bold mb-6">Departments</h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {departments.map((dept) => (
            <Link href={dept.hasOrders ? `/department/${dept.id}` : "#"} key={dept.id}>
              <DepartmentCard name={dept.name} hasOrders={dept.hasOrders} />
            </Link>
          ))}
        </div>
      </div>
    </main>
  )
}

